import os
import paramiko

# Set the file path
file_path = '/home/pi/Desktop/test.txt'

# Create an SSH server object
ssh = paramiko.SSHClient()

# Automatically add the client's RSA key (for first time connections)
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# Start the SSH server
ssh.connect('192.168.43.239', username='pi', password='raspberry')

# Open an SFTP session
sftp = ssh.open_sftp()

# Receive the file
sftp.get(os.path.basename(file_path), file_path)

# Close the SFTP session and the SSH connection
sftp.close()
ssh.close()
