from picamera import PiCamera
import udpNetwork as udp
import time
import os
import shutil

port=5002

## WLAN Address
'''
addr_slaveLeft="192.168.43.164"
addr_slaveRight="192.168.43.239"
addr_master="192.168.43.192"
'''

## Ethernet Address
addr_slaveLeft="192.168.137.164"
addr_slaveRight="192.168.137.239"
addr_master="192.168.137.192"

camera = PiCamera()
time.sleep(0.5)
camera.resolution = (1280, 720)
camera.vflip = True

file_name = "/home/pi/Pictures/Master.h264"

msgRight=udp.recv(port,addr_master,1024)
time.sleep(0.5)
msgLeft=udp.recv(port,addr_master,1024)
time.sleep(0.5)

timeF=int(input('Enter Record Length (s): '))

if(msgRight==b'R' and msgLeft==b'R'):
	udp.send(bytes(str(timeF).encode('UTF-8')),port,addr_slaveLeft)
	udp.send(bytes(str(timeF).encode('UTF-8')),port,addr_slaveRight)
	time.sleep(0.2)
	udp.send(b'S',port,addr_slaveLeft)
	udp.send(b'S',port,addr_slaveRight)
	print("Start recording...")
	camera.start_recording(file_name)
	camera.wait_recording(timeF)
	camera.stop_recording()
	print("Done.")
	print(time.time())

flashLoc=os.listdir('/media/pi/')
print (flashLoc)
time.sleep(0.5)
udp.send(bytes(flashLoc[0].encode('UTF-8')),port,addr_slaveLeft)
udp.send(bytes(flashLoc[0].encode('UTF-8')),port,addr_slaveRight)
time.sleep(1)
shutil.copy('/home/pi/Pictures/Master.h264', f'/media/pi/{flashLoc[0]}')
print('Master Copied...')
