from bluedot.btcomm import BluetoothServer as blt
from signal import pause
import time

def my_callback():
	server1.send("Hello I am Master")

def data_received(data):
	print(f"[RECEIVED]>> {0}",format(data))

def client_connected():
	print("Client Connected")

def client_disconnected():
	print("Client Disconnected")

print("Bluetooth Init....")
server1=blt(data_received, auto_start=False, when_client_connects=client_connected, when_client_disconnects=client_disconnected)

print("Starting....")

server1.start()
print("[MY_ADDRESS_TO_CONNECT_1]>> {0}",format(server1.server_address))
print("Waiting for Connection....")

while True:
	try:
		time.sleep(0.1)
		my_callback()
	except Exception as e:
		print("[ERROR]>> {0}", format(str(e)))
		print("Stopping....")
		server1.stop()
