from bluedot.btcomm import BluetoothClient as blt
from signal import pause
import time

def data_received(data):
 print(f"[RECEIVED]>> {0}",format(data))
 slave.send( 'Hi Master I am Slave Right' )

print("Bluetooth Connecting....")
slave=blt("E4:5F:01:80:BE:BF",data_received, auto_connect=False)

while True:
 try:
  slave.connect()
  while(not slave.connected):
   slave.connect()
  time.sleep(0.13)
  slave.disconnect()
 except Exception as e:
  print("Bluetooth Disconencting....")
