from picamera import PiCamera
from sshFileTransfer import fileTransfer
import udpNetwork as udp
import time

port=5002

## WLAN Address
'''
addr_slaveLeft="192.168.43.164"
addr_slaveRight="192.168.43.239"
addr_master="192.168.43.192"
'''

## Ethernet Address
addr_slaveLeft="192.168.137.164"
addr_slaveRight="192.168.137.239"
addr_master="192.168.137.192"

camera = PiCamera()
time.sleep(0.5)
camera.resolution = (1280, 720)
camera.vflip = True
camera.contrast = 10

file_name = "/home/pi/Pictures/slaveRight" + ".h264"


udp.send(b"R",port,addr_master)
timeF=int(str(udp.recv(port,addr_slaveRight,1024).decode()))
msgMaster=udp.recv(port,addr_slaveRight,1024)

if(msgMaster==b'S'):
	print("Start recording...")
	camera.start_recording(file_name)
	camera.wait_recording(timeF)
	camera.stop_recording()
	print("Done.")
	print(time.time())

flashLoc=str(udp.recv(port,addr_slaveRight,1024).decode())
print(flashLoc)
fileTransfer("~/Pictures/slaveRight.h264",f"/media/pi/{flashLoc}",addr_master)
