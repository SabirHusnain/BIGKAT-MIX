import os

def fileTransfer(pathFrom,pathTo,ip):
        command=f"scp {pathFrom} pi@{ip}:{pathTo}"
        print('Starting File Tranfer')
        os.system(command)
        print('File Transfered Successfully')

if __name__=='__main__':
	fileTransfer('/home/pi/Pictures/slaveRight.h264','/home/pi/Desktop','192.168.137.192')
