from picamera import PiCamera
import time

camera = PiCamera()
time.sleep(0.5)
camera.resolution = (1280, 720)
camera.vflip = True

file_name = "/home/pi/Pictures/video_" + str(time.time()) + ".h264"

print("Start Recording Right...")
camera.start_recording(file_name)
camera.wait_recording(12)
camera.stop_recording()
print("Done.")
print(time.time())
