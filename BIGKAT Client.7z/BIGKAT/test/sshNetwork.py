import paramiko

# Create an SSH client object
ssh = paramiko.SSHClient()

# Automatically add the server's RSA key (for first time connections)
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# Connect to the remote server
ssh.connect('192.168.43.192', username='pi', password='raspberry')

# Open a channel to send messages
channel = ssh.invoke_shell()

# Send a message
channel.send('Hello from the slaveRight!\n')

# Receive a message
#while True:
 #   if channel.recv_ready():
  #      output = channel.recv(4096).decode()
   #     if output:
    #        print(output)
     #   else:
      #      break

# Close the connection
channel.close()
ssh.close()
