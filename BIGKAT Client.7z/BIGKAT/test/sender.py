import os
import paramiko

# Set the file path
file_path = '/home/pi/Desktop/test.txt'

# Create an SSH client object
ssh = paramiko.SSHClient()

# Automatically add the server's RSA key (for first time connections)
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# Connect to the remote server
ssh.connect('192.168.43.192', username='pi', password='raspberry')

# Open an SFTP session
sftp = ssh.open_sftp()

# Send the file
sftp.put(file_path, os.path.basename(file_path))

# Close the SFTP session and the SSH connection
sftp.close()
ssh.close()
